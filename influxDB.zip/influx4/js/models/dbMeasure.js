export default function Measure(my_measurement,my_time,my_value,my_plant_key,my_sid) {
    this.measurement = my_measurement;
    this.time = my_time;
    this.value = my_value;
    this.plant_key = my_plant_key;
    this.sid = my_sid;
  }
